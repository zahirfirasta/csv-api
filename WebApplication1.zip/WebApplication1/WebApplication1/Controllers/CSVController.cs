﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Text;
using System.Web.Http;

namespace WebApplication1.Controllers
{
    public class CSVController : ApiController
    {
       
        
        // GET: api/CSV/5
        public string Get(int id)
        {
            List<Models.ContactInfo> contacts = new List<Models.ContactInfo>();
            for (int i = 0; i < id; i++)
            {
                contacts.Add(new Models.ContactInfo() { Id = i, Firstname = $"ABC-{i}", Lastname = $"XYZ-{i}" });
            }
            var result = ToCsv<Models.ContactInfo>(",", contacts);
            return result;
        }
        public  string ToCsv<T>(string separator, IEnumerable<T> objectlist)
        {
            Type t = typeof(T);
            PropertyInfo[] fields = t.GetProperties();

            string header = String.Join(separator, fields.Select(f => f.Name).ToArray());

            StringBuilder csvdata = new StringBuilder();
            csvdata.AppendLine(header);

            foreach (var o in objectlist)
                csvdata.AppendLine(ToCsvFields(separator, fields, o));

            return csvdata.ToString();
        }

        public  string ToCsvFields(string separator, PropertyInfo[] fields, object o)
        {
            StringBuilder linie = new StringBuilder();

            foreach (var f in fields)
            {
                if (linie.Length > 0)
                    linie.Append(separator);

                var x = f.GetValue(o);

                if (x != null)
                    linie.Append(x.ToString());
            }

            return linie.ToString();
        }
       
    }
}
